#include <stdio.h>

int main() {
    int i;

    printf("Angka 1 sampai 10:\n");
    for(i = 1; i <= 10; i++) {
        printf("%d ", i);
    }

    return 0;
}
