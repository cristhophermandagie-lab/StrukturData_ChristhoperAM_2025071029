#include <stdio.h>

int main() {
    int nilai[5];
    int i;
    int total = 0;
    float rata;

    // Input 5 nilai
    for(i = 0; i < 5; i++) {
        printf("Masukkan nilai ke-%d: ", i + 1);
        scanf("%d", &nilai[i]);
        total += nilai[i];
    }

    // Hitung rata-rata
    rata = total / 5.0;

    // Output hasil
    printf("Total nilai = %d\n", total);
    printf("Rata-rata = %.2f\n", rata);

    return 0;
}
