#include <stdio.h>

int main() {
    int i;

    printf("Bilangan genap dari 1 sampai 50:\n");
    for(i = 2; i <= 50; i += 2) {
        printf("%d ", i);
    }

    return 0;
}
