#include <stdio.h>

int main() {
    int N, i;
    int jumlah = 0;

    printf("Masukkan nilai N: ");
    scanf("%d", &N);

    for(i = 1; i <= N; i++) {
        jumlah += i;
    }

    printf("Jumlah bilangan dari 1 sampai %d adalah %d\n", N, jumlah);

    return 0;
}
